//
//  LGPPhotoBrowser.h
//  三图复用
//
//  Created by apple on 16/8/3.
//  Copyright © 2016年 廖国朋. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    LGPPhotosIsOneDimensionalArray, //默认
    LGPPhotosIsTwoDimensionalArray // 为二维数组
} LGPPhotosAttribute;


@interface LGPPhotoBrowser : UIView

@property (nonatomic,strong)UIImage *placeholderImage;
@property (nonatomic,strong)NSArray *photos;
@property (nonatomic,assign)LGPPhotosAttribute attribute;


@property (nonatomic,assign)NSInteger line;
@property (nonatomic,assign)NSInteger column;

@end
