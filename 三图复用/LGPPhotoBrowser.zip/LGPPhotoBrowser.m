//
//  LGPPhotoBrowser.m
//  三图复用
//
//  Created by apple on 16/8/3.
//  Copyright © 2016年 廖国朋. All rights reserved.
//


#import "LGPPhotoBrowser.h"
#import "LGPBrowserImageView.h"
#import "SDPhotoBrowserConfig.h"

@interface LGPPhotoBrowser ()<UIScrollViewDelegate>

@property (nonatomic,strong)LGPBrowserImageView *leftView;
@property (nonatomic,strong)LGPBrowserImageView *rightView;
@property (nonatomic,strong)LGPBrowserImageView *currentView;

@property (nonatomic,assign)NSInteger rightLine;
@property (nonatomic,assign)NSInteger leftLine;

@property (nonatomic,assign)NSInteger rightIndex;
@property (nonatomic,assign)NSInteger leftIndex;
@property (nonatomic,assign)NSInteger currentIndex;

@property (nonatomic,strong)UIScrollView *scrollView;
@property (nonatomic,strong)UILabel *indexLabel;
@property (nonatomic,strong)UIActivityIndicatorView *indicatorView;
@property (nonatomic,strong)UIView *headView;

@end
@implementation LGPPhotoBrowser

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];

    _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0,WIDTH, frame.size.height)];
    _scrollView.showsHorizontalScrollIndicator = NO;
    self.backgroundColor = SDPhotoBrowserBackgrounColor;
    _scrollView.backgroundColor = SDPhotoBrowserBackgrounColor;

    [self addSubview:_scrollView];
    
    _leftView = [[LGPBrowserImageView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, frame.size.height)];
    _currentView = [[LGPBrowserImageView alloc]initWithFrame:CGRectMake(WIDTH, 0, WIDTH, frame.size.height)];
    _rightView = [[LGPBrowserImageView alloc]initWithFrame:CGRectMake(WIDTH*2, 0, WIDTH, frame.size.height)];
    NSArray *arr = @[_leftView,_currentView,_rightView];
    
    for (LGPBrowserImageView *view in arr) {
        // 单击图片
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoClick:)];
        // 双击放大图片
        UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageViewDoubleTaped:)];
        doubleTap.numberOfTapsRequired = 2;
        
        [singleTap requireGestureRecognizerToFail:doubleTap];
        [view addGestureRecognizer:singleTap];
        [view addGestureRecognizer:doubleTap];
        [_scrollView addSubview:view];
    }
    [self setHeadView];
    _scrollView.pagingEnabled = YES;
    [_scrollView setContentOffset:CGPointMake(WIDTH, 0)];
    _scrollView.delegate = self;
    
    return self;
}

- (void)setHeadView{
//    self.headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, 64)];
//    self.headView.backgroundColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:1.0];
//    [self addSubview:self.headView];
    _indexLabel = [[UILabel alloc]init];
    _indexLabel.bounds = CGRectMake(0, 0, 80, 30);
    _indexLabel.textAlignment = NSTextAlignmentCenter;
    _indexLabel.textColor = [UIColor whiteColor];
    _indexLabel.font = [UIFont boldSystemFontOfSize:20];
    _indexLabel.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    _indexLabel.layer.cornerRadius = _indexLabel.bounds.size.height * 0.5;
    _indexLabel.clipsToBounds = YES;
    
    [self addSubview:_indexLabel];
}

- (void)setPhotos:(NSArray *)photos{
    _photos = photos;
}

- (void)didMoveToSuperview{
    
    _scrollView.contentSize = CGSizeMake((_attribute==LGPPhotosIsOneDimensionalArray)&&(_photos.count==1||_photos.count==0)?0:WIDTH*3, 0);
    [_scrollView setContentOffset:CGPointMake(WIDTH, 0)];
    
    if (_attribute==LGPPhotosIsOneDimensionalArray) {
        if (self.line >= _photos.count) {
            self.line = 0;
            NSLog(@"下标错误");
        }
        _currentIndex = self.line;
        _indexLabel.text = [NSString stringWithFormat:@"%ld/%ld", self.line + 1, self.photos.count];

    }else{
        
        if (self.line >= _photos.count) {
            self.line = 0;
            self.column = 0;
            NSLog(@"下标错误");
        }
        
        NSArray *arr = _photos[self.line];
        if (self.column >= arr.count) {
            self.column = 0;
            NSLog(@"下标错误");
        }
        self.leftLine = self.line;
        self.rightLine = self.line;
        
        _currentIndex = self.column;
        _indexLabel.text = [NSString stringWithFormat:@"%ld/%ld", self.column + 1, arr.count];
    }

    [self hanldeIndexWithCurrentIndex:_currentIndex];

    [self setImage];
    _indexLabel.center = CGPointMake(self.bounds.size.width * 0.5, 35);
    
}

- (void)photoClick:(UITapGestureRecognizer *)recognizer
{
    WeakObj(self);
    [UIView animateWithDuration:SDPhotoBrowserHideImageAnimationDuration animations:^{
        
        selfWeak.alpha = 0;
        
    } completion:^(BOOL finished) {
        [selfWeak removeFromSuperview];
    }];
}


- (void)imageViewDoubleTaped:(UITapGestureRecognizer *)recognizer
{
    LGPBrowserImageView *imageView = (LGPBrowserImageView *)recognizer.view;
    CGFloat scale;
    if (imageView.isScaled) {
        scale = 1.0;
    } else {
        scale = 2.0;
    }
    
    [imageView doubleTapToZommWithScale:scale];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    
    if(scrollView.contentOffset.x >= WIDTH*2){
        
        [_currentView clear];
        
        _currentIndex++;
        if (_attribute==LGPPhotosIsOneDimensionalArray) {

            if(_currentIndex > (_photos.count - 1)){
                
                _currentIndex = 0;
            }
            self.line = _currentIndex;
            
        }else{
            NSArray *arr = _photos[_line];
            if (_currentIndex > (arr.count - 1)) {
                
                self.line += 1;
                if (self.line > (_photos.count - 1)) {
                    self.line = 0;
                }
                _currentIndex = 0;
            }
            self.column = _currentIndex;
        }
        
    }else if (scrollView.contentOffset.x <= 0){
        
        [_currentView clear];
        
        _currentIndex--;
        if (_attribute==LGPPhotosIsOneDimensionalArray) {

            if(_currentIndex < 0){
                
                _currentIndex = _photos.count - 1;
            }
            self.line = _currentIndex;
        }else{
            if (_currentIndex < 0) {
                self.line -= 1;
                if (self.line < 0) {
                    self.line = _photos.count - 1;
                }
                NSArray *arr = _photos[_line];
                _currentIndex = arr.count-1;
            }
            self.column = _currentIndex;
        }
        
    }
    if (_attribute==LGPPhotosIsOneDimensionalArray) {
        _indexLabel.text = [NSString stringWithFormat:@"%ld/%ld", self.line + 1, self.photos.count];
    }else{
        NSArray *arr = _photos[self.line];
        _indexLabel.text = [NSString stringWithFormat:@"%ld/%ld", self.column + 1, arr.count];
    }
//    NSLog(@"%ld:%ld",_leftLine,_leftIndex);
//    NSLog(@"%ld:%ld",_line,_currentIndex);
//    NSLog(@"%ld:%ld",_rightLine,_rightIndex);
//
//
//    [self hanldeIndexWithCurrentIndex:_currentIndex];
//    NSLog(@"--------------------");
//    NSLog(@"%ld:%ld",_leftLine,_leftIndex);
//    NSLog(@"%ld:%ld",_line,_currentIndex);
//    NSLog(@"%ld:%ld",_rightLine,_rightIndex);
//    NSLog(@"====================");

//    _pageControl.currentPage = _currentIndex;
//    _currentView.index = _currentIndex;
    
    [self setImage];
    
    [scrollView setContentOffset:CGPointMake(WIDTH, 0) animated:NO];
}

- (void)setImage{
    
    [_currentView setImageWithURL:(_attribute==LGPPhotosIsOneDimensionalArray)?_photos[_currentIndex]:_photos[_line][_currentIndex] placeholderImage:_placeholderImage];
    
    [_leftView setImageWithURL:(_attribute==LGPPhotosIsOneDimensionalArray)?_photos[_leftIndex]:_photos[_leftLine][_leftIndex] placeholderImage:_placeholderImage];
    
    [_rightView setImageWithURL:(_attribute==LGPPhotosIsOneDimensionalArray)?_photos[_rightIndex]:_photos[_rightLine][_rightIndex] placeholderImage:_placeholderImage];
}

- (void)hanldeIndexWithCurrentIndex:(NSInteger)curIndex{
    
    _leftIndex = curIndex - 1;
    _rightIndex = curIndex + 1;

    if (_attribute==LGPPhotosIsOneDimensionalArray) {
        self.line = curIndex;
        if(_leftIndex < 0){
            _leftIndex = _photos.count - 1;
        }
        
        if(_rightIndex > _photos.count - 1){
            _rightIndex = 0;
        }
        
    }else{
        self.column = curIndex;
        if(_leftIndex < 0){
            
            self.leftLine = self.line - 1;
            if (self.leftLine < 0) {
                self.leftLine = _photos.count - 1;
            }
            
            NSArray *arr = _photos[self.leftLine];
            _leftIndex = arr.count - 1;
        }else{
            self.leftLine = self.line;
        }
        
        NSArray *arr = _photos[self.line];
        if(_rightIndex > (arr.count - 1)){
            self.rightLine = self.line + 1;
            if (self.rightLine > (_photos.count - 1)) {
                self.rightLine = 0;
            }
            _rightIndex = 0;
        }else{
            self.rightLine = self.line;
        }
    }
    
}
//保存图片操作  调用即可
- (void)saveImage
{
    UIImageWriteToSavedPhotosAlbum(_currentView.image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
    
    UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] init];
    indicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
    indicator.center = self.center;
    [[UIApplication sharedApplication].keyWindow addSubview:indicator];
    if (_indicatorView&&_indicatorView.isAnimating) {
        return;
    }
    _indicatorView = indicator;
    [indicator startAnimating];
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo;
{
    [_indicatorView removeFromSuperview];
    
    UILabel *label = [[UILabel alloc] init];
    label.textColor = [UIColor whiteColor];
    label.backgroundColor = [UIColor colorWithRed:0.1f green:0.1f blue:0.1f alpha:0.90f];
    label.layer.cornerRadius = 5;
    label.clipsToBounds = YES;
    label.bounds = CGRectMake(0, 0, 150, 30);
    label.center = self.center;
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont boldSystemFontOfSize:17];
    [[UIApplication sharedApplication].keyWindow addSubview:label];
    [[UIApplication sharedApplication].keyWindow bringSubviewToFront:label];
    if (error) {
        label.text = SDPhotoBrowserSaveImageFailText;
    }   else {
        label.text = SDPhotoBrowserSaveImageSuccessText;
    }
    [label performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:1.0];
}

@end
